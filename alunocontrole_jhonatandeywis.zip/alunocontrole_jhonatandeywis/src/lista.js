export default [
    {
      title: "Atividades",
      data: [
        {task: 'Tarefa 01', done:true},
        {task: 'Tarefa 02', done:true},
        {task: 'Tarefa 03', done:false},
        {task: 'Tarefa 04', done:false},
        {task: 'Tarefa 05', done:true},
        {task: 'Tarefa 06', done:false},
        {task: 'Tarefa 07', done:false},
        {task: 'Tarefa 08', done:true},
        {task: 'Tarefa 09', done:false},
        {task: 'Tarefa 10', done:true},
        {task: 'Tarefa 12', done:false},
        {task: 'Tarefa 13', done:true},
        {task: 'Tarefa 14', done:true},
        {task: 'Tarefa 15', done:false}
      ]
    }
    
]