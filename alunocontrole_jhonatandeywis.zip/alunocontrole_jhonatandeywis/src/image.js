import React from 'react';
import styled from 'styled-components/native';
import { Box, Image, NativeBaseProvider } from 'native-base';

export default () => {
  return (
    <Box
      p={2}
    >
    <Image
      source={{
        uri: "https://blog-static.infra.grancursosonline.com.br/wp-content/uploads/2016/08/ifac-001.png",
      }}
      alt="IFAC"
      resizeMode="cover"
      width={210}
      height={52}
    />
    </Box>
  )
}